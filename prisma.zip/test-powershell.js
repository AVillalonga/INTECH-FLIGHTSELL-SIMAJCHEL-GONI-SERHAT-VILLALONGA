import { PowerShell } from 'node-powershell';
PowerShell.$`echo "hello from PowerShell"`;